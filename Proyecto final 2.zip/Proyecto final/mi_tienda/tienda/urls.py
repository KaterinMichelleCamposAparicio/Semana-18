from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='index'),  # Página principal
    path('buscar/', views.buscar_producto, name='buscar_producto'),
    path('registrarse/', views.register, name='register'),
    path('iniciar-sesion/', views.login, name='login'),
    path('contacto/', views.contact, name='contact'),
    path('sobre-nosotros/', views.about, name='about'),
    path('productos/', views.products, name='products'),  # Ruta para productos
    path('agregar-producto/', views.add_product, name='add_product'),  # Nueva ruta para agregar productos
    path('cerrar-sesion/', views.logout_view, name='logout'),  # Ruta para cerrar sesión
    path('agregar/<int:producto_id>/', views.agregar_al_carrito, name='agregar_al_carrito'),
    path('ver_carrito/', views.ver_carrito, name='ver_carrito'),
    path('eliminar/<int:producto_id>/', views.eliminar_del_carrito, name='eliminar_del_carrito'),
    path('limpiar/', views.limpiar_carrito, name='limpiar_carrito'),
    path('producto/<int:producto_id>/', views.detalle_producto, name='detalle_producto'),
    path('productos/', views.lista_productos, name='lista_productos'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
